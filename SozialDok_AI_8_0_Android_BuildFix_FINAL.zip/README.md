# SozialDok AI 8.0 – Release Candidate / Verkaufsbasis

Diese Version bündelt die bisherige Entwicklung als nutzbares Desktop-/Web-/Mobile-Projekt.

## Schnellstart Windows
1. Node.js LTS installieren.
2. ZIP entpacken.
3. `BUILD_WINDOWS.bat` ausführen.
4. Für Entwicklung: `npm start`.

## Demo
E-Mail: `admin@sozialdok.local`
Passwort: `admin123`

Vor produktiver Nutzung unbedingt eigenes Benutzerkonto, starkes Passwort, HTTPS, Datenbank, Backups und Sicherheitskonzept einrichten.

## Wichtig für Verkauf
Die Anwendung ist technisch als Release-Basis vorbereitet. Ein signierter Windows-Installer, Apple-App und Google-Play-Release müssen in der jeweiligen Build-/Signierumgebung erzeugt werden. Zugangsdaten, Datenschutz, Auftragsverarbeitung und rechtliche Produktfreigabe müssen vor Verkauf geprüft werden.

## Architektur
- Electron Desktop App mit eigenem Icon
- responsive Web-App
- Capacitor-Projekt für Android/iOS
- lokales Express-Backend
- JWT-Login
- bcrypt Passwort-Hashing
- Klienten- und Berichtsdaten
- Diktataufnahme
- professionelle Berichtsvorlage
- Anonymisierung und verpflichtender Datenschutz-Hinweis
- Verlauf, TXT, Kopieren, Drucken/PDF


## Mobile Release 8.0
Android- und iOS-Build-Konfigurationen sowie konkrete Build-Anleitungen befinden sich unter `BUILD_MOBILE.md` und `mobile/android/README.md` bzw. `mobile/ios/README.md`.
