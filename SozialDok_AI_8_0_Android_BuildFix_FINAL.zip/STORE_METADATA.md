# Store-Metadaten – SozialDok AI

## App Name
SozialDok AI

## Kurzbeschreibung
Professionelle KI-gestützte Dokumentation für soziale und pflegerische Arbeitsfelder.

## Kategorie
Business / Productivity

## Zielgruppe
Fachkräfte und Einrichtungen in Sozialarbeit, Pflege, beruflicher Rehabilitation, WfbM und vergleichbaren Arbeitsfeldern.

## Datenschutz-Hinweis
Vor Veröffentlichung müssen Datenschutzerklärung, Datenflüsse, KI-Dienstleister, Auftragsverarbeitung und ggf. besondere Kategorien personenbezogener Daten rechtlich geprüft werden.

## Bundle / Package ID
`de.sozialdok.ai`
