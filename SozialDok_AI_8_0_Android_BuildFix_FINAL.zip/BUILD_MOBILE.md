# SozialDok AI 8.0 – Android & iOS Build

## Android APK / AAB
Voraussetzungen: Windows/macOS/Linux + Node.js LTS + Android Studio + JDK 17.

```text
cd mobile
npm install
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio:
- Build > Generate Signed Bundle / APK
- APK für direkte Installation
- Android App Bundle (AAB) für Google Play

Paket-ID: `de.sozialdok.ai`

## iPhone / iPad IPA
Voraussetzungen: macOS + Xcode + Apple Developer Account.

```text
cd mobile
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

In Xcode Signing Team auswählen und anschließend Archive/TestFlight/App Store verwenden.

## App-Symbol
Das Master-Icon befindet sich unter `assets/icon.svg` und `assets/icon.png`.
Für Store-Release müssen daraus die von Android/iOS geforderten Icon-Größen erzeugt und in die nativen Projekte übernommen werden.

## Wichtiger Produktionspunkt
Die mobile App ist eine Client-Oberfläche. Für echte Kundendaten sollte das Backend über HTTPS erreichbar sein. API-Schlüssel gehören nicht fest in die mobile App.
