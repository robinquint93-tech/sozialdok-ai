# Produktions- und Verkaufscheckliste

## Muss vor echtem Kundeneinsatz erledigt sein
- [ ] Demo-Zugang deaktivieren oder Passwort ändern
- [ ] eigener `SD_JWT_SECRET` über sichere Umgebungsvariable
- [ ] HTTPS/TLS und sichere Serverkonfiguration
- [ ] echte Datenbank statt JSON-Datei
- [ ] Rollen/Rechte (Admin, Fachkraft, Lesen)
- [ ] Audit-Log
- [ ] Verschlüsselung ruhender Daten und Backups
- [ ] Lösch-/Aufbewahrungskonzept
- [ ] Datenschutz-/DSGVO-Prüfung und Auftragsverarbeitungsverträge
- [ ] KI-Dienstleister und Datenübermittlung rechtlich/vertraglich prüfen
- [ ] keine unbelegten Diagnosen oder Tatsachen generieren
- [ ] Penetration-/Security-Test
- [ ] signierte Windows-/macOS-Builds
- [ ] App-Store-/Play-Store-Metadaten und Datenschutzerklärung
- [ ] Support-/Updateprozess
- [ ] Lizenzmodell, AGB, Impressum und Widerrufs-/Verbraucherinformationen (falls relevant)
