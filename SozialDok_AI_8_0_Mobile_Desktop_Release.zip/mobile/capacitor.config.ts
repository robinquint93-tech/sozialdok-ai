import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "de.sozialdok.ai",
  appName: "SozialDok AI",
  webDir: "../app",
  bundledWebRuntime: false
};

export default config;
