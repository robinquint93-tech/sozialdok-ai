@echo off
setlocal
echo SozialDok AI - Windows Build
where node >nul 2>nul || (echo Node.js fehlt. Bitte Node.js LTS installieren.&pause&exit /b 1)
call npm install
if errorlevel 1 (echo npm install fehlgeschlagen.&pause&exit /b 1)
call npm run make
if errorlevel 1 (echo Build fehlgeschlagen.&pause&exit /b 1)
echo Fertig. Die Windows-Ausgabe liegt unter make\.
pause
