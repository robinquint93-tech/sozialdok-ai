# Android Build

## Voraussetzungen
- Android Studio
- Android SDK
- JDK 17
- Google Play Console account for Play Store release

## Erstmalige Erstellung
Im Ordner `mobile`:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`

Danach in Android Studio:
- applicationId: `de.sozialdok.ai`
- App name: `SozialDok AI`
- Version Name/Code setzen
- Signing Key/Keystore anlegen
- `Build > Generate Signed Bundle / APK`

Für Google Play: **Android App Bundle (.aab)** erzeugen.
Für direkte Installation: **Signed APK (.apk)** erzeugen.

Das Android-Projekt wird von Capacitor erzeugt, weil Android Studio/Gradle die plattformspezifischen Build-Dateien bereitstellt.
