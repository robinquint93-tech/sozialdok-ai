# iOS Build

## Voraussetzungen
- macOS
- Xcode
- Apple Developer Account
- gültiges Team/Signing-Zertifikat

## Erstmalige Erstellung
Im Ordner `mobile`:
1. `npm install`
2. `npx cap add ios`
3. `npx cap sync ios`
4. `npx cap open ios`

In Xcode:
- Bundle Identifier: `de.sozialdok.ai`
- Display Name: `SozialDok AI`
- Signing Team auswählen
- Version/Build setzen
- App Icon eintragen
- Archive erstellen
- über Xcode Organizer zu TestFlight/App Store hochladen

Eine `.ipa` wird im Apple-Signing-Prozess erzeugt. Das erfordert macOS/Xcode und ein Apple-Entwicklerkonto.
