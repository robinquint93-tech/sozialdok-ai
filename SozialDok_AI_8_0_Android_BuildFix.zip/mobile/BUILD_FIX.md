# Android Build Fix

Capacitor configuration is intentionally JSON (not TypeScript) to avoid config parser issues in cloud builds.
TypeScript is pinned to 5.9.2 for Capacitor 7 compatibility.
