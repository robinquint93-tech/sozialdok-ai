# Installation

## Desktop
Windows: `BUILD_WINDOWS.bat`  
macOS/Linux: `npm install` und anschließend `npm run make`.

## Server
`cd server` → `npm install` → `node server.js`.

Produktiv `SD_JWT_SECRET` setzen und den Demo-Account ersetzen.

## Mobile
Im Projektverzeichnis `mobile` die Capacitor-Abhängigkeiten installieren, native Plattformen hinzufügen und anschließend in Android Studio/Xcode signieren.
